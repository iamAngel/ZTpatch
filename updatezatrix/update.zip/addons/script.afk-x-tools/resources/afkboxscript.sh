#!/bin/sh
#kodi-send -a "Notification(afkboxscript.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwerken van Opdracht:,$1,$TIME,/storage/.kodi/addons/plugin.program.afk-x-tools/resources/afkboxscript.png)" &> /dev/null
  echo $1
}

checkUSB(){
	USB=$(df | grep /dev/sda)
	if [[ "$USB" == "" ]]; then
		myInfo 'geen USB apparaat gevonden!'
		exit
	fi
}

if [[ "$1" == "clean" ]]; then
	myInfo 'Opschonen verouderde addons'
	rm -rf /var/media/STORAGE2/*
	sleep 5
	myInfo 'Add-ons Opschonen geslaagd'
fi

if [[ "$1" == "cleanthumb" ]]; then
	myInfo 'Afbeeldingen verwijderen'
	rm /storage/.kodi/userdata/Database/Textures13.db
	rm -rf /storage/.kodi/userdata/Thumbnails/*
	sleep 3
	myInfo 'Afbeeldingen verwijderd - AFK-Box herstart nu!'
	sleep 3
    reboot
fi